#!/bin/bash

# gather login creds
echo "Login to obn-pre-staging application:"
read -p 'Username: ' uservar </dev/tty

read -sp 'Password: ' passvar </dev/tty
echo ""
echo "Provide pre-staging ethernet interface name (Press ENTER for default: enp5s0)"
read -p 'Interface: ' interfacevar </dev/tty
interfacevar=${interfacevar:-enp5s0}
echo ""

echo "Provide pre-staging vlan id (Press ENTER for default: 1)"
read -p 'Interface: ' vlanidvar </dev/tty
vlanidvar=${vlanidvar:-1}

# store creds in hiera
sudo sed -i "s,obn_pre_staging::username: \".*\",obn_pre_staging::username: \"$uservar\"", ./hieradata/common.yaml
sudo sed -i "s,obn_pre_staging::password: \".*\",obn_pre_staging::password: \"$passvar\"", ./hieradata/common.yaml
sudo sed -i "s,networking::ethernet_interface: \".*\",networking::ethernet_interface: \"$interfacevar\"", ./hieradata/common.yaml
sudo sed -i "s,networking::vlan_id: \".*\",networking::vlan_id: \"$vlanidvar\"", ./hieradata/common.yaml

#!/bin/bash

# gather login creds
echo "Login to obn-pre-staging application:"
read -p 'Username: ' uservar </dev/tty

read -sp 'Password: ' passvar </dev/tty

echo "Provide pre-staging ethernet interface name"
read -p 'Interface: ' interfacevar </dev/tty

# store creds in hiera
sudo sed -i "s,obn_pre_staging::username: \".*\",obn_pre_staging::username: \"$uservar\"", ./hieradata/common.yaml
sudo sed -i "s,obn_pre_staging::password: \".*\",obn_pre_staging::password: \"$passvar\"", ./hieradata/common.yaml
sudo sed -i "s,networking::interface: \".*\",networking::interface: \"$interfacevar\"", ./hieradata/common.yaml

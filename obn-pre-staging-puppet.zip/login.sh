#!/bin/bash

# gather login creds
echo "Login to obn-pre-staging application:"
read -p 'Username: ' uservar </dev/tty

read -sp 'Password: ' passvar </dev/tty

# store creds in hiera
sed -i "s,obn_pre_staging::username: \".*\",obn_pre_staging::username: \"$uservar\"", ./hieradata/common.yaml
sed -i "s,obn_pre_staging::password: \".*\",obn_pre_staging::password: \"$passvar\"", ./hieradata/common.yaml

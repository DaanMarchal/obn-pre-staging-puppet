require 'puppet_x'

# common PuppetX::Stdlib module definition
module PuppetX::Stdlib; end

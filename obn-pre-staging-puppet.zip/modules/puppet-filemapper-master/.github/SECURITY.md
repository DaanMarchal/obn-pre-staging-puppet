# Vox Pupuli Security Policy

Our vulnerabilities reporting process is at https://voxpupuli.org/security/
